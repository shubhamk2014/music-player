import {
    createBrowserRouter,
} from "react-router-dom";
import { MonthlyBarSales } from "../Analytics/monthlybar";
import { ProductPieSales } from "../Analytics/productpie";
import { Dash } from "../LeftMenu/lftmn";
import { BillDash } from "../Billing/billdash";
import { Login } from "../Login/Login";
import { CustomerDash } from "../Dash/customer";
import { NewCustomer } from "../Dash/newcust";
import { NewBill } from "../Billing/newbill";
import { BillDeet } from "../Billing/billdetails";
import { CustDeet } from "../Dash/customerdetail";


export const router = createBrowserRouter([
    {
        path: '/',
        element: <Login/>,
    },
    {
        path: '/redirect',
        element: <h1>hi</h1>,
    },
    {
        path: '/lftmn',
        element: <Dash operation= {() => <CustomerDash/>}/>,
    },
    {
        path: '/testing',
        element: <Dash operation= {() => <CustomerDash/>}/>,
    },
    {
        path: '/custdash',
        element:<Dash operation= {() => <CustomerDash/>}/>,
    },
    {
        path: '/newbill',
        element:<Dash operation= {() => <NewBill/>}/>,
    },
    {
        path: '/newcust',
        element:<Dash operation= {() => <NewCustomer/>}/>,
    },
    {
        path: '/custdeet/:mobile',
        element:<Dash operation= {() => <CustDeet/>}/>,
    },
    {
        path: '/billdetails/:billno',
        element:<Dash operation= {() => <BillDeet/>}/>,
        
    },
    {
        path: '/billdash',
        element:<Dash operation= {() => <BillDash/>}/>,
        
    },
    {
        path: '/productsales',
        element:<Dash operation= {() => <ProductPieSales/>}/>,
        
        
    },
    {
        path: '/monthlysales',
        element:<Dash operation= {() => <MonthlyBarSales/>}/>,
        
        
    },
])