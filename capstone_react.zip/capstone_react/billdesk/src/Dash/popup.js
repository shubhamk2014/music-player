import { ServerStyleSheet } from 'styled-components'
import styles from './popup.module.css'
import { useEffect, useState } from 'react'
import { EMAIL_REGEX } from '../Context/consts.js'
import styled from 'styled-components'
import { useNavigate } from 'react-router-dom'
import { Warning } from '../Messsages/messages'

const Form = styled.input`
    width:200px;
    height:10px;
    margin-bottom:0px;
    font-size:11px;
`

function VerticalInput({ label, onIp, name, type, valid }) {
    return (<>
        <h3 className={styles.label}>{label}</h3>
        <Form name={name} type={type} onChange={onIp} className={valid ? styles.valid : styles.invalid} />
    </>)
}

function VerticalInputDate({ label, onIp, name, type, valid }) {
    const today = new Date().toISOString().split("T")[0];

    return (<>
        <h3 className={styles.label}>{label}</h3>
        {(valid)}
        <Form name={name} type={type} onChange={onIp} max={today} className={valid ? "" : styles.invalid} />
    </>)
}

export function PopUpForm({ visible, data, idx, toggle, refresh }) {

    const navigate = useNavigate()
    let flag = false
    const re = EMAIL_REGEX
    const [formdata, setFormdata] = useState({ id: idx, name: '', mobile: null, dob: null, email: "" })
    const [errors, setError] = useState("")
    const [valid, setValid] = useState({ name: true, mobile: true, dob: true, email: true })
    useEffect(() => { }, [idx, valid])
    const onIp = (e) => {
        setFormdata({ ...formdata, [e.target.name]: e.target.value })
    }
    const submitForm = () => {

        let validin = true
        let req = formdata
        req = { ...req, id: idx }
        let temp = valid
        console.log(req)
        if (req.name === "") {
            temp = ({ ...temp, name: false })
            validin = false
        }
        else { temp = ({ ...temp, name: true }) }
        if (req.mobile === null) {
            temp = ({ ...temp, mobile: false })
            validin = false
        }
        else { temp = ({ ...temp, mobile: true }) }
        if (req.email === "" || req.email === null) {
            temp = ({ ...temp, email: false })
            if (!re.test(req.email)) setError("Invalid Email ID")
            validin = false
        }
        else { temp = ({ ...temp, email: true }) }
        if (!re.test(req.email)) {
            setError("Invalid Email ID")
            validin = false
        }
        else { temp = ({ ...temp, email: true }) }
        if (req.dob === "")
            req = ({ ...req, dob: null })
        setValid(temp)
        console.log(temp)
        if (!validin) { return -1 }
        fetch("http://localhost:7760/billdesk/updatecust/", {
            method: 'put',
            body: JSON.stringify(req),
            headers: {
                'Content-type': 'application/json'
            }
        })
            .then(res => {
                if (!res.ok) return Promise.reject(res)
                else {
                    flag = true
                    setFormdata({ id: null, name: '', mobile: null, dob: null, email: "" })
                    return res.json()
                }

            })
            .then(res => {
                console.log(flag)
                console.log(res)
            })
            .then(dummy => {
                if (flag) {
                    setError("")
                    toggle(false)
                    navigate("/custdeet/" + formdata.mobile)
                }
            })
            .catch(errRes => {
                console.log(errRes)
                errRes.json().then(res => {
                console.log(res)
                setError(res.error[0])
                })
            })



    }

    if (visible) {
        return (
            <div className={styles.opacity}>
                <div className={styles.box}>
                    <h2>Update Customer Details <button style={{ marginLeft: `80px`, width: `25px`, height: `25px`, fontSize: `10px`, textAlign: 'center' }} onClick={() => {
                        setError("")
                        toggle(false)
                    }}>x</button> </h2>
                    <VerticalInput name='name' label='Name' onIp={onIp} valid={valid.name} />
                    <VerticalInput name='mobile' type='number' label='Mobile' onIp={onIp} valid={valid.mobile} />
                    <VerticalInputDate name='dob' type='date' label='Date of Birth' onIp={onIp} valid={valid.dob} />
                    <VerticalInput name='email' type='email' label='E-Mail ID' onIp={onIp} valid={valid.email} />
                    <br />
                    <button onClick={submitForm}>Submit</button>
                    <Warning text={errors} />


                </div>
            </div>
        )
    }





    else return (<></>)
}


export function PopUpConfirm({ visible, toggle, info, setinfo, confirm }) {
    const [del, setdelMes] = useState("")
    const onYes = () => {
        console.log(info.idx)
        fetch("http://localhost:7760/billdesk/deactivate/", {
            method: 'put',
            body: JSON.stringify({ id: info.idx }),
            headers: {
                'Content-type': 'application/json'
            }
        })
            .then(res => {
                if (!res.ok) return Promise.reject(res)
                return res.json()
            })
            .then(json => console.log(json))
            .then(dum => {
                toggle(false)
                confirm("User " + info.name + " deleted")
            })
            .catch(errRes => errRes.json().then(console.log(errRes)))
    }
    const onNo = () => {
        setinfo({ name: "", idx: null })
        toggle(false)
    }
    if (visible) {
        return (
            <div className={styles.opacity}>
                <div className={styles.smallbox}>

                    <Warning text={"Are you sure you want to delete customer with name " + info.name + "?"} style={{ textAlign: "center" }}></Warning>
                    <button onClick={onYes}>Yes</button><button style={{ marginLeft: `20px` }} onClick={onNo}>No</button>
                </div></div>
        )
    }

    else return (<></>)
}