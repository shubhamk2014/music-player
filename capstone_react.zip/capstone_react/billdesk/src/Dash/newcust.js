import styles from "./customer.module.css"
import styled from "styled-components"
import { useEffect, useState } from "react";
import { Success,Warning } from "../Messsages/messages";
import { EMAIL_REGEX } from '../Context/consts.js'




export function NewCustomer() {
    const re = EMAIL_REGEX
    const date = new Date().toISOString().split("T")[0];
    const [inpval, setVal] = useState({ 'name': true, 'email': true, 'mobile': true, 'dob': true })
    const [errors, setErrors] = useState({ 'name': '', 'email': '', 'mobile': '', 'dob': '', 'general': '' })
    const [mess, setMess] = useState("")
    const [form, setForm] = useState({ 'name': '', 'email': '', 'mobile': null, 'dob': null })
    useEffect(() => { }, [form])
    const onSubmit = () => {
        console.log(form)
        let temp = { 'name': true, 'email': true, 'mobile': true, 'dob': true }
        let temperror = { 'name': '', 'email': '', 'mobile': '', 'dob': '' }
        let flag = 1
        if (!re.test(form['email'])) {
            flag = 0
            temperror = { ...temperror, email: 'Invalid Email ID' }
            temp = { ...temp, email: false }
        }
        if (form['mobile'] < 1000000000 || form['mobile'] > 10000000000) {
            flag = 0
            temperror = { ...temperror, mobile: 'Must have 10 digits' }
            temp = { ...temp, mobile: false }
        }
        for (var i of Object.keys(form)) {
            if (form[i] === "" || form[i] === null)  {
                if (!(i === "dob")) flag = 0
                temp = ({ ...temp, [i]: false })
                temperror = { ...temperror, [i]: i + " field cannot be blank" }

            }
            if(isNaN(form['mobile'])) {
                temp = ({ ...temp, mobile: false })
                temperror = { ...temperror, mobile: "mobile field cannot be blank" }
            }

        }
        temp = { ...temp, dob: true }
        temperror = { ...temperror, dob: '' }
        if (form['dob'] === "") { setForm({ ...form, dob: null }) }
        console.log(flag)
        if (flag === 1) {

            console.log(JSON.stringify(form))
            fetch("http://localhost:7760/billdesk/", {
                method: 'post',
                body: JSON.stringify(form),
                headers: {
                    'Content-type': 'application/json'
                }
            })
                .then(res => {
                    if (!res.ok) return Promise.reject(res)
                    return res.json()
                })
                .then(res => console.log(res))
                .then(dummy => setMess('Created Successfully'))
                .catch(errRes => errRes.json().then(
                    e => {setErrors({...errors,general:e.error[0]})
                    setMess('')}
                ))



        }
        else {
            setMess("")
        }
        setErrors(temperror)

        setVal(temp)
    }
    const update = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value })
    }
    const updateNum = (e) => {
        setForm({ ...form, [e.target.name]: parseInt(e.target.value) })
    }

    return (
        <div className={styles.vertbox}>
            <div className={styles.container}></div>
            <h1>New Customer</h1>
            <h3>Name</h3>
            <input type="text" className={inpval.name ? styles.inbox : styles.invalid} name='name' onChange={update} />
            <Warning text={errors.name}/>
            <h3>Email</h3>
            <input type="email" className={inpval.email ? styles.inbox : styles.invalid} name='email' onChange={update} />
            <Warning text={errors.email}/>
            <h3>Phone mobile</h3>
            <input type="number" className={inpval.mobile ? styles.inbox : styles.invalid} name='mobile' onChange={updateNum} />
            <Warning text={errors.mobile}/>
            <h3>Date of Birth</h3>
            <input type="date" max={date} className={inpval.dob ? styles.inbox : styles.invalid} name='dob' onChange={update} />
            <Warning text={errors.dob}/>
            <button onClick={onSubmit}> Submit </button>
            <Success text={mess}/>
            <Warning text={errors.general}/>
        </div>
    )
}