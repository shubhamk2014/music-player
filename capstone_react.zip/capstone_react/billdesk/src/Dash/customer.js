import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { BasicTable, CustTable } from "../Table/table";
import { PopUpConfirm, PopUpForm } from "./popup";
import styles from './customer.module.css'
import { Warning } from "../Messsages/messages";


export function CustomerDash() {
    const [deletedUser,setDelMess] =useState("")
    const [idx,setIdx] = useState(null)
    const [del,setDel] = useState({name:'plc',idx:2})
    const [render,setRender] = useState(null)
    const [popstate, setPop] = useState(false)
    const [confstate,setConf] = useState(false)
    const [formdata, setFormdata] = useState({ id: '', mobile: '', name: '', dob: '', created: '' })
    const [data, setData] = useState([{ id: '', mobile: '', name: '', dob: '', created: '' }])
    
    useEffect(() => {
        fetch('http://localhost:7760/billdesk/')
            .then(res => {
                if (!res.ok) return Promise.reject(res)
                return res.json()
            })
            .then(res => {
                setData(res)
            })
            .catch(errRes => console.log(errRes.json()))
    }, [])
    
    useEffect(() => {
        fetch('http://localhost:7760/billdesk/')
            .then(res => {
                if (!res.ok) return Promise.reject(res)
                return res.json()
            })
            .then(res => {
                setData(res)
            })
            .catch(errRes => console.log(errRes.json()))
    }, [deletedUser])

    useEffect(() => { }, [data])

    return (
        <div className={styles.vertbox}>
            <div className={styles.tablebox}>
                <PopUpConfirm visible={confstate} info={del} setinfo={setDel} toggle={setConf} confirm={setDelMess}/>
                <PopUpForm visible={popstate} data={formdata} toggle={setPop} idx={idx} formset={setFormdata} refresh={setRender}/>
                <CustTable indata={data} pop={setPop} formset={setIdx} delset={setDel} conf={setConf} setform={setFormdata}/>
                <Warning text={deletedUser}/>
            </div>
        </div>
    )
}