import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import styles from './customer.module.css'
import { Link } from 'react-router-dom'
import { PAYMENT_METHODS } from '../Context/consts'
import { PopUpForm } from './popup'

const data = { 'test': 'placeholder' }

export function RowEntity({ data, prop }) {
    return (
        <tr>
            <td>{prop.replace(/^\w/, c => c.toUpperCase())}</td>
            <td>{data[prop]}</td>
        </tr>
    )
}


export function CustDeet() {
    const mobile = useParams()
    console.log(mobile)
    const [custinfo, setInfo] = useState({ name: "", email: "", mobile: "", dob: "" })
    const [bills, setBills] = useState([])
    const [billsall,setBillsAll] = useState([])
    useEffect(() => {
        fetch("http://localhost:7760/billdesk/" + mobile.mobile + "/custinfo")
            .then(res => {
                if (!res.ok) return Promise.reject(res)
                return res.json()
            })
            .then(json => {
                setInfo(json)
                console.log(json)
            })

        fetch("http://localhost:7760/billing/" + mobile.mobile + "/billcust")
            .then(res => {
                if (!res.ok) return Promise.reject(res)
                return res.json()
            })
            .then(json => { 
                setBills(json.slice(0,3))
                setBillsAll(json)
            })
    }, [])

    useEffect(() => { }, [bills])


    const showAll = () =>{
        setBills(billsall)
    }





    return ( <>
        <h1 style={{fontSize:`50px`,marginLeft:`40px`}}>Customer Info</h1>
        <div className={styles.albox + " " + styles.vertbox}>
            
            <div>
                <table>
                    <tbody>
                        <RowEntity data={custinfo} prop='name' />
                        <RowEntity data={custinfo} prop='email' />
                        <RowEntity data={custinfo} prop='mobile' />
                        <RowEntity data={custinfo} prop='dob' />
                    </tbody>
                </table>
            </div>
            <br></br>
            <br></br>
            <div className={styles.tablebox}>
                
                <table>
                    <thead>
                    <tr>
                            <td>Bill Number</td>
                            <td>Mobile</td>
                            <td>Amount</td>
                            <td>Payment Method</td>
                            </tr>
                    </thead>
                    {bills.map(bill => (
                        <tr>
                            <td><Link to={"/billdetails/"+bill.billno}>{bill.billno}</Link></td>
                            <td>{bill.billdate}</td>
                            <td>{bill.amount}</td>
                            <td>{PAYMENT_METHODS[bill.paymeth-1]}</td>
                            </tr>
                    )
                    )}
                </table>


            </div>
            <button style={{fontSize:`18px`}} onClick={showAll}>Show All Bills</button>
        </div>
        </>
    )
}