
import { useContext,useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AppCtx } from '../Context/ctx'
import styles from './Login.module.css'


export function Login() {

    const ctx = useContext(AppCtx)
    const [formValid,setValid] = useState({username:true,password:true})
    const [formErrors,setErrors] = useState({username:"",password:"",login:""})
    const navigate = useNavigate()

    useContext(()=>{navigate("/lftmn")},[ctx])

    const onClick = () => {


        let username = document.getElementById('username').value
        let password = document.getElementById('password').value
        let temp = {username,password}

        // Validation
        let flag = 0
        let status = {username:true,password:true}
        let error = {username:"",password:""}
        if (temp.username === "") {
            status = {...status,username:false}
            error = {...error,username:"Please enter a username"}
            flag = 1
        }
        if (temp.password === "") {
            status = {...status,password:false}
            error = {...error,password:"Please enter a password"}
            flag = 1
        }
        setValid(status)
        setErrors(error)
        
        if (flag === 1) {
            return -1
        }
        


        //
        fetch('http://localhost:7760/admin/login/',{
            method : 'put',
            body : JSON.stringify(temp),
            headers : {
                'Content-type' : 'application/json'
            }
        })
        .then(res => {
            if (!res.ok) return Promise.reject(res)
            ctx.setCtx(temp.username)
            return res.json()
        })
        .then(json => {
            ctx.setCtx(temp.username)
            ctx.setCash(json.cashier)
            navigate("/custdash")}
        )
        .catch(errRes => {
            errRes.json()
            .then(
                json => {
                    setErrors({login:json.error[0]})})
        })
        

    }

    return (
        <div className={styles.container}>
            <div className={styles.loginbox}>
                <div className={styles.subbox}>
                <h1> Login </h1>
                <p> Sign in to continue </p>
                </div>
                <div className={styles.subbox}>
                    <input type="text" placeholder="Username" id='username' className={formValid.username ? '' : styles.invalid}/>
                    <p className = {styles.error}>{formErrors.username} </p>
                    <input type="text" placeholder="Password" id='password' className={formValid.password ? '' : styles.invalid}/>
                    <p className = {styles.error}>{formErrors.password}</p>
                    <button styles={styles.subbox} onClick={onClick}>Submit</button>
                    <p className = {styles.error}>{formErrors.login}</p>
                    {ctx.context}
                </div>
            </div>
        </div>
    )
}