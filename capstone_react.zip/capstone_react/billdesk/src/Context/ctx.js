import { createContext } from "react";

export const AppCtx = createContext()