import { useEffect, useMemo, useState } from "react"
import { Legend, Pie, PieChart, Tooltip } from "recharts"
import { COLORS } from "../Context/consts"

import styles from './analytics.module.css'
import { Cell } from "recharts"

const RADIAN = Math.PI / 180;
const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, index,name }) => {
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + (radius+50) * Math.cos(-midAngle * RADIAN);
  const y = cy + (radius+50) * Math.sin(-midAngle * RADIAN);

  return (
    <text x={x<400?x-40:x} y={y} fill="black" >
        
      {name+'\n'+`${(percent * 100).toFixed(0)}%`}
      
    </text>
  );
}

export function ProductPieSales() {


    const [piedata, setData] = useState([])
    useEffect(() => {
        fetch("http://localhost:7760/item/piestats")
            .then(res => {
                if (!res.ok) return Promise.reject.res
                return res.json()
            })
            .then(json => {
                setData(json)
                console.log(json)
            })


    }, [])

    



    return (
        <div className={styles.container + " " + styles.vertflex}>
            <div>
                <h1> Product Sales </h1>
                <h2> Year : 2022</h2>
                <h2> Total items : {piedata.length} </h2>
            </div>


            <hr/>
                <div className={styles.horbox}>

                    <PieChart width={800} height={400}>
                        <Pie width={100} height={100} data={piedata} dataKey="Total" nameKey="Item" cx="50%" cy="50%" innerRadius={80} outerRadius={100} fill="#111" paddingAngle={5} />
                        <Pie width={100} height={100} data={piedata} dataKey="Quants" nameKey="Item" cx="50%" cy="50%" innerRadius={110} outerRadius={130} paddingAngle={5} fill="#888" label={renderCustomizedLabel} />
                        <Tooltip />
                    </PieChart>
                    <div className={styles.vertflex}>
                        <h2 style={{ color: "#888" }}>Quantity of Sale</h2>
                        <h2 style={{ color: "#111" }}> Value of Sale</h2>
                    </div>

                </div>
        </div>
    )
}
