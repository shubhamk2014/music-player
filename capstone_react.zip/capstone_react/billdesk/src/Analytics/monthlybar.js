import { useEffect, useState } from "react"
import { Bar, BarChart } from "recharts"
import { CartesianGrid, XAxis, YAxis, Tooltip, Legend } from "recharts"
import styles from './analytics.module.css'
export function MonthlyBarSales() {
    const [bardata, setData] = useState([])
    const [total,setTotal] = useState(0)
    useEffect(() => {
        fetch("http://localhost:7760/item/monthly")
            .then(res => {
                if (!res.ok) return Promise.reject.res
                return res.json()
            })
            .then(json => {
                setData(json)
                console.log(json)
            })


    }, [])

    useEffect(() => {
        let subtotal = 0
        for (var Obj in bardata) {
            (subtotal += bardata[Obj].amount)
            console.log('total',subtotal)
        }
        setTotal(subtotal)
     }, [bardata])

    return (
        <div className={styles.container + " " + styles.vertflex}>
            <div>
                <h1> Product Sales </h1>
                <h2> Year : 2022</h2>
                <h2> Total Sales : {total} </h2>
            </div>
            <div className={styles.horbox}>

                <BarChart width={730} height={250} data={bardata}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="amount" fill="#BBB" label />
                </BarChart>

            </div></div>)
    
}


