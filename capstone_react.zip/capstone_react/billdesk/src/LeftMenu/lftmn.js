import { Link, Navigate, useNavigate } from "react-router-dom"
import { useContext, useEffect, useState } from "react"
import styles from './lftmn.module.css'
import styled from 'styled-components'
import './lftmn.module.css'
import { AppCtx } from "../Context/ctx"

const White = styled.a`
    
`
export function Dash({ operation }) {
    const date = new Date().toISOString().split("T")[0];
    const ctx = useContext(AppCtx)
    const navigate = useNavigate()
    useEffect(() => {
        if (ctx.context==="") {
            console.log("Bounce")
            navigate("/")}
    },[])
    
    const [menustate, setMenu] = useState({ customer: false, analytics: false,bill:false })
    useEffect(() => { console.log(menustate) }, [menustate])
    const onClk = (e) => {
        setMenu({[e.target.name]: !menustate[e.target.name] })
    }
    return (
        <div className={styles.container}>
        <div className={styles.topbar}>
            <Link href="/">Hey, {ctx.context}</Link>
            <div style={{display:'flex'}}>
            <p style={{color:'white'}}>{date}</p>
            <a href="/">Logout</a>
            </div>
        </div>
        <div className={styles.bottombox}>
        <div className={styles.leftmenu}>
            <button name="bill" className ={styles.menubutton} onClick={onClk}>Bill</button><br/>
            <div className={menustate.bill? styles.customermenu : styles.hidden }>
                <ul>
                    <li><Link to="/newbill">New Bill</Link></li>
                    <li><Link to="/billdash">Bill Details</Link></li>
                </ul>

            </div>
            <button name="customer" className={styles.menubutton} onClick={onClk}>Customer</button>
            <div className={menustate.customer? styles.customermenu : styles.hidden }>
                <ul>
                    <li><Link to="/newcust">New Customer</Link></li>
                    <li><Link to="/custdash/">Customer Details</Link></li>

                </ul>

            </div>
            <button name="analytics" className={styles.menubutton} onClick={onClk}>Analytics</button>
            <div className={menustate.analytics? styles.customermenu : styles.hidden }>
                <ul>
                    <li><Link to="/monthlysales">Monthly Sales</Link></li>
                    <li><Link to="/productsales">Product Sales</Link></li>
                </ul>

            </div>
        </div>
        <div>
            {operation()}
        </div>
        </div>
        </div>
    )
}


