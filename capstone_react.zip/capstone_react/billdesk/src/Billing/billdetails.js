import { useContext, useEffect,useState } from 'react'
import { useParams } from 'react-router-dom'
import { PAYMENT_METHODS,GST } from '../Context/consts'
import  {Link } from 'react-router-dom'
import styles from './billingdeets.module.css'
import { AppCtx } from '../Context/ctx.js'

function TRow({name,val}) {
    return (
        <tr>
            <td>{name}</td>
            <td>{val}</td>
        </tr>
    )
}

export function BillDeet() {
    const ctx = useContext(AppCtx)
    console.log(ctx)
    const [billdata,setbilldata] = useState([])
    const [billinfo,setbillinfo] = useState({})
    const billno = useParams()
    var path = "/custdeets/"
    useEffect(()=>{
        fetch("http://localhost:7760/item/billitems/",{
            method : 'put',
            body : JSON.stringify(billno),
            headers : {
                'Content-type' : 'application/json'
            }
        })
        .then(res=>{if (!res.ok) return Promise.reject(res)
        return res.json()})
        .then(json => {
            console.log(json)
            setbilldata(json)})
        .catch()

        fetch("http://localhost:7760/billing/billdeets/",{
            method : 'put',
            body : JSON.stringify(billno),
            headers : {
                'Content-type' : 'application/json'
            }
        })
        .then(res=>{if (!res.ok) return Promise.reject(res)
            return res.json()})
            .then(json => {
                console.log(json)
                setbillinfo(json)
                var path = "/custdeets/"+billinfo.mobile})
            .catch()
    },[])
    return (
        
        <div className={styles.container}>
        
        <h1 style={{fontSize:`50px`}}>Bill Details</h1>
            <div className={styles.infoflex}>
                <table>
                    <TRow name="Bill#" val={billinfo.billno}/>
                    <td>Mobile</td>
                     <span style={{display:`none`}}>{path =  "/custdeet/"+billinfo.mobile}</span>
                     <td><Link to={path}>{billinfo.mobile}</Link></td>
                    <TRow name="Payment Method" val={PAYMENT_METHODS[billinfo.paymeth-1]}/>
                </table>
                <table>
                    <TRow name="Date" val={billinfo.billdate}/>
                    <TRow name="Cashier" val={billinfo.cashier}/>
                    <TRow name="Counter" val={billinfo.counter}/>
                </table>
                
            </div>
            <div className={styles.tablebox}>
                <table>
                    <thead>
                        <th className={styles.header}>Items</th>
                        <th className={styles.header}>Quantity</th>
                        <th className={styles.header}>Price</th>
                        <th className={styles.header}>Subtotal</th>
                    </thead>
                    <tbody>
                        {billdata.map(el => {
                            return (
                                <tr>
                                <td>{el.Item}</td>
                                <td>{el.Quantity}</td>
                                <td>{el.Price}</td>
                                <td>{el.itemtotal}</td>
                                </tr>
                            )
                        })}
                        <tr>
                            <td style={{textAlign:`right`}}colSpan={3}>Total</td>
                            <td>{billinfo.amount/(1+GST)}</td>
                        </tr>
                        <tr>
                            <td style={{textAlign:`right`}}colSpan={3}>GST</td>
                            <td>{(billinfo.amount*GST/(1+GST)).toFixed(2)}</td>
                        </tr>
                        <tr>
                            <td style={{textAlign:`right`}}colSpan={3}>Grand Total</td>
                            <td>{billinfo.amount}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    )
    
    }