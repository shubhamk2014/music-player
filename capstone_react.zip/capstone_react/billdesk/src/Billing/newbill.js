import { BillTable, CustTable, NoReactTable } from '../Table/table'
import { useState, useRef, useEffect, useContext } from 'react'
import styles from './billing.module.css'
import { AppCtx } from '../Context/ctx'
import { Warning } from '../Messsages/messages'
import { AlNum, PAYMENT_METHODS } from '../Context/consts.js'
import { useNavigate } from 'react-router-dom'

function OptionBox({ arr }) {
    return (
        <select className={styles.choices} id='paymeth'>
            {
                arr.map((el, index) => (<option value={index + 1}>{el}</option>))
            }
        </select>

    )
}
export function VerticalInput({ label, val, up, type = 'text', error, validator }) {
    const onInp = (e) => {
        up({ ...val, [e.target.name]: e.target.value })

    }
    return (
        <div>
            <h3>{label}</h3>
            <input name={label} className={validator ? "" : styles.invalid} type={type} onChange={onInp}></input>
            <Warning text={error} />
        </div>
    )
}

export function NewBill() {


    const re = AlNum
    const navigate=useNavigate()
    const itemno = useRef(1)
    const [counter, setCounter] = useState(1)
    const ctx = useContext(AppCtx)
    const date = new Date().toISOString().split("T")[0];
    const [billItems, setBillItems] = useState([])
    const [inpval, setVal] = useState({ Quantity: true, Price: true, Item: true })
    const [totals, setTotal] = useState({ items: 0, price: 0, grand: 0 })
    const [entry, setEntry] = useState({ id: null, Item: '', Quantity: '', Price: '' })
    const [mobileOk, setOk] = useState(false)
    const [data, setData] = useState([{ id: '', mobile: '', name: '', dob: '', created: '' }])
    const [errors, setErrors] = useState({ Item: '', Quantity: '', Price: '',Response:'' })
    const [ph, setPh] = useState(0)

    useEffect(() => { }, [mobileOk, errors,billItems,totals])


    const checkOut = () => {
        if (billItems.length === 0) {
            setErrors({...errors,Response:"Add Atleast 1 Item!"})
            return -1
        }
        setErrors({...errors,Response:""})
        var billno = null
        let paymeth = document.getElementById('paymeth')
        paymeth = paymeth.value
        let bill = { mobile: ph, counter, cashier: ctx.cashier, amount: totals.grand, paymeth }
        fetch('http://localhost:7760/billing/', {
            method: 'post',
            body: JSON.stringify(bill),
            headers: {
                'Content-type': 'application/json'
            }
        })
            .then(res => {
                if (!res.ok) return Promise.reject(res)
                return res.json()
            })
            .then(json => {
                console.log(json.billno)
                return json.billno
            })
            .then(billno => {
                    let billCopy = billItems
                    billCopy = billCopy.map((el) => {
                        return ({...el,billno})
                    })
                    console.log('copy',billCopy)
                    


                for (var obj in billCopy) {

                    fetch('http://localhost:7760/item/', {
                        method: 'post',
                        body: JSON.stringify(billCopy[obj]),
                        headers: {
                            'Content-type': 'application/json'
                        }
                    })
                        .then(res => {
                            if (!res.ok) return Promise.reject(res)
                            return res.json()
                        })
                        .then(json => { console.log(json) })
                        .catch(errRes => errRes.json().then(
                            err => console.log(err)
                        ))
                }
                console.log(billno)
                return billno
            })
            .then(billno => navigate("/billdetails/"+billno))
    }


const checkNum = () => {
    if(ph<1000000000 || ph>=10000000000) {setErrors({mobile: "Invalid Number"})
    setOk(false)}
    else {
    fetch('http://localhost:7760/billdesk/mobilecheck/', {
        method: 'put',
        body: JSON.stringify({ mobile: ph }),
        headers: {
            'Content-type': 'application/json'
        }

    })
        .then(res => {
            if (!res.ok) return Promise.reject(res)
            return res.json()
        })
        .then(res => {
            setOk(true)
            setErrors({ ...errors, mobile: "" })
        })
        .catch(errRes => errRes.json()
            .then(val => {
                setErrors({ ...errors, mobile: val.error[0] })
                setOk(false)
            }

            )
        )
        }
}



const addBillItem = () => {
    let temp = billItems
    let temperrors = { Item: '', Quantity: '', Price: '' }
    let tempval = { Item: '', Quantity: '', Price: '' }
    let flag = 0
    if (!re.test(entry.Item)) {
        flag = 1
        tempval = { ...tempval, Item: false }
        temperrors = ({ ...temperrors, Item: "Invalid Value" })
    }
    else {
        tempval = { ...tempval, Item: true }
        setErrors({ ...errors, Item: "" })
    }
    if (entry.Quantity <= 0) {
        flag = 1
        tempval = { ...tempval, Quantity: false }
        temperrors = ({ ...temperrors, Quantity: "Invalid Value" })

    }
    else {
        tempval = { ...tempval, Quantity: true }
        temperrors = ({ ...temperrors, Quantity: "" })
    }
    if (entry.Price <= 0) {
        flag = 1
        tempval = { ...tempval, Price: false }
        temperrors = ({ ...temperrors, Price: "Invalid Value" })
    }
    else {
        tempval = { ...tempval, Price: true }
        temperrors = ({ ...temperrors, Price: "" })
    }
    if (flag === 1) {
        setErrors(temperrors)
        setVal(tempval)
        return -1
    }

    setErrors({ Item: '', Quantity: '', Price: '' })
    temp = [...temp, { ...entry, id: itemno.current,itemtotal:(entry.Quantity * entry.Price)}]
    let tot_temp = { items: parseInt(entry.Quantity) + totals.items, price: (entry.Quantity * entry.Price) + totals.price }
    tot_temp = { ...tot_temp, grand: (tot_temp.price * 1.18).toFixed(2) }
    setTotal(tot_temp)
    setBillItems(temp)
    itemno.current = itemno.current + 1

}


return (
    <div className={styles.maincont}>
        <div className={styles.horflex}>
            <div>
                <h1>New Bill</h1>
                <h3>Mobile</h3>

                <input type='number' placeholder='Enter Mobile' onChange={(e) => { setPh(e.target.value) }} />
                <button onClick={checkNum}>Search</button>
                <Warning text={errors.mobile} />
            </div>
            <div>
                <p>Date: {date}</p>
                <p>Cashier: {ctx.cashier}</p>
                <p>Counter: {counter} </p>
            </div>
        </div>


        <hr />
        <div className={(mobileOk ? "" : styles.hidden)}>
            <div className={styles.horflex + " " + styles.squeeze}>
                <VerticalInput label="Item" val={entry} up={setEntry} error={errors.Item} validator={inpval.Item} />
                <VerticalInput label="Quantity" val={entry} up={setEntry} type="number" error={errors.Quantity} validator={inpval.Quantity} />
                <VerticalInput label="Price" val={entry} up={setEntry} type="number" error={errors.Price} validator={inpval.Price} />
                <button onClick={addBillItem}>Add</button>
            </div>
            {/* {JSON.stringify(entry)} */}
            {/* {JSON.stringify(billItems)} */}
            {/*<BillTable indata={billItems} total={totals} setitems={setBillItems} settotals={setTotal} />*/}
            <NoReactTable indata={billItems} total={totals} setitems={setBillItems} settotals={setTotal} />

            <div className={styles.horflex + " " + styles.rightalignflex}>
                <Warning text={errors.Response}/>
                <button onClick={checkOut}>Checkout</button>
                <OptionBox arr={PAYMENT_METHODS} />
            </div>
        </div>
    </div>
)
}