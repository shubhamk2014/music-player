import { Link } from "react-router-dom";
import styles from './billdash.module.css'
import styled from "styled-components";
import { BillDashTable } from "../Table/table";
import { useEffect, useState } from "react";
function SearchInput({type,name,pl,val,ch}) {
    return (<div className={styles.vertbox}>
    <h3 className={styles.label}>{pl}</h3>
    <input type={type} name={name} placeholder={pl} className={styles.searchinput} onChange={(e) => ch({...val,[e.target.name]:e.target.value})}/>
    </div>)
}

const SinkLabel = styled.h2`
    margin:0px;
    font-size:25px;
    position:absolute;
    background-color:white;
    width:100px;
    text-align:center;
    margin-left:25px;
`
export function BillDash() {
    const [bills,setBills] = useState([])
    const [filterfields,setFields] = useState({mobile:null,billno:null,billdate:"",counter:null,cashier:""})
    const refreshData = () => {
        fetch('http://localhost:7760/billing/')
        .then(res => {if (!res.ok) return Promise.reject(res)
                    return res.json()})
                    .then(json =>{console.log(json)
                    let temp = json.map((el,i) => {return {...el,id:i+1}})
                    setBills(temp)
                })
    }

    const serverFilter = () => {
        let temp = {}
        if (filterfields.billdate==="") {
            temp = ({...filterfields,billdate:null})
        }
        else {
            temp = filterfields
        }
        if (filterfields.mobile==="") {
            temp = ({...temp,mobile:null})
        }
        else {
            temp = temp
        }
        if (filterfields.counter==="") {
            temp = ({...temp,counter:null})
        }
        else {
            temp = temp
        }
        if (filterfields.billno==="") {
            temp = ({...temp,billno:null})
        }
        else {
            temp = temp
        }
        
        fetch('http://localhost:7760/billing/billquery/',{
            method : 'put',
            body : JSON.stringify(temp),
            headers : {
                'Content-type' : 'application/json'
            }
        })
        .then(res => {if (!res.ok) return Promise.reject(res)
                    return res.json()})
                    .then(json =>{console.log(json)
                    let temp = json.map((el,i) => {return {...el,id:i+1}})
                    setBills(temp)
                })
                .catch(errRes=> errRes.json().then(res => console.log(res)))
    }
    
    useEffect(()=>{
        fetch('http://localhost:7760/billing/')
        .then(res => {if (!res.ok) return Promise.reject(res)
                    return res.json()})
                    .then(json =>{console.log(json)
                    let temp = json.map((el,i) => {return {...el,id:i+1}})
                    setBills(temp)
                })
    },[])

    useEffect(()=>{},[bills])
    return(
        <div className={styles.container}>
            <div className={styles.horbox} style={{justifyContent:"space-between"}}>
                <h1>Bill</h1><Link to="/newbill">New Bill</Link>
                {JSON.stringify}
                </div>
            <SinkLabel>Search</SinkLabel>
            <br/>
            <div className={styles.borderbox}>
                <div className={styles.horbox}>
                <SearchInput name="mobile" type="number" pl="Mobile" val={filterfields} ch={setFields}/>
                <SearchInput name="billno" type="number" pl="Bill Number" val={filterfields} ch={setFields}/>
                <SearchInput name="billdate" type="date" pl="Date" val={filterfields} ch={setFields}/>
                </div>
                <div className={styles.horbox}>
                <SearchInput name="counter" type="number" pl="Counter" val={filterfields} ch={setFields}/>
                <SearchInput name="cashier" pl="Cashier" val={filterfields} ch={setFields}/>
                <div className={styles.vertbox}>
                <button style={{height:`30px`,marginTop:`45px`,marginLeft:`15px`,fontSize:`15px`,marginBottom:`5px`}} onClick={serverFilter}>Search</button>
                <button style={{height:`30px`,marginTop:`0px`,marginLeft:`15px`,fontSize:`15px`}} onClick={refreshData}>Clear Filters</button>
                </div>
                </div>    
                
            </div>
            <br/>
            <div className={styles.anotherfuckingtable}>
                <BillDashTable indata={bills}/>
            </div>
            <div></div>
        </div>
    )
}