import styles from './messages.module.css'

export function Warning({text}) {
    return(
        <>
            <p className={styles.warning}>{text}</p>
        </>
    )
}

export function Success({text}) {
    return(
        <>
            <p className={styles.success}>{text}</p>
        </>
    )
}