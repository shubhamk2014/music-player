
import styles from './table.module.css'
import { useState } from "react"

const inputstyle ={
    width:`100px`,
    height:`15px`,
    marginTop:`20px`,
    padding:`0px`,
    fontSize:`10px`,
    borderRadius:`5px`,
}

export function ColumnFilter({column}) {
    const { filterValue, setFilter} = column
    const [mobSearch,setMob] = useState('')
    return (
        <div className={styles.horbox}>
            <input placeholder={column.Header}
            style={inputstyle} 
            value = {filterValue || ''} 
            onChange = {(e) => setFilter(e.target.value)}

            />
        </div>
    )
}