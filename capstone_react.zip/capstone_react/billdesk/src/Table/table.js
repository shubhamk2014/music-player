import { useMemo, useState } from "react";
import { CUSTCOLUMNS, BILLCOLUMNS, BILLTABLECOLS, AcButton } from "./columns";
import { useTable, usePagination, useFilters } from 'react-table'
import { useEffect } from "react";
import { AppCtx } from '../Context/ctx.js'
import { GST } from '../Context/consts.js'
import styles from './table.module.css'
import styled from "styled-components";
import { ColumnFilter } from "./columnfilter";
import { Link } from 'react-router-dom'
import { PopUpForm } from "../Dash/popup";
//import { useFetcher } from "react-router-dom";


const Pagin = styled.button`
width:100px;
height:40px;
`


export function CustTable({ indata, pop, formset, delset, conf, setform }) {
    var columns = useMemo(() => CUSTCOLUMNS, [])
    var data = useMemo(() => indata, [indata])





    const tablehooks = (hooks) => {
        hooks.visibleColumns.push((columns) => [
            ...columns,
            {
                id: 'actions',
                Header: 'Actions',
                Cell: (({ row }) => (<>
                    <button className={styles.actionbutton} onClick={() => {
                        pop(true)
                        console.log(row.values.id)
                        formset(row.values.id)
                    }}>
                        Edit
                    </button>
                    <button className={styles.actionbutton} onClick={() => {
                        conf(true)
                        delset({ name: row.values.name, idx: row.values.id })
                        setform({ name: '', email: '', mobie: null, dob: null })
                    }}>
                    Delete
                </button>
                </>
                ))

}
        ]);
    }
const tableInstance = useTable({
    columns,
    data,
},
    useFilters,
    usePagination,
    tablehooks)

const {
    page,
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    canPreviousPage,
    canNextPage,
    pageOptions,
    pageCount,
    gotoPage,
    nextPage,
    previousPage,
    setPageSize,
    state: { pageIndex, pageSize }
} = tableInstance

useEffect(() => { setPageSize(3) }, [])
return (
    <>
        <table {...getTableProps} className={styles.mintable}>
            <thead>
                {headerGroups.map((headerGroup) => (
                    <tr {...headerGroup.getHeaderGroupProps}>
                        {
                            headerGroup.headers.map(column => (
                                <th {...column.getHeaderProps()}>
                                    {column.Header === 'Sr' ? <h1>Customers</h1> : ""}
                                    {column.Header === "Name" ? <Link to="/newcust"> New Customer </Link> : ""}
                                    {column.Header === 'Mobile' ? column.render('Filter') : ""}</th>
                            ))
                        }
                    </tr>
                ))}
            </thead>
        </table>
        <table {...getTableProps()} className={styles.maintable}>

            <thead>
                {headerGroups.map((headerGroup) => (
                    <tr {...headerGroup.getHeaderGroupProps}>
                        {
                            headerGroup.headers.map(column => (
                                <th {...column.getHeaderProps()}>{column.render('Header')}</th>
                            ))
                        }
                    </tr>
                ))}
            </thead>
            <tbody {...getTableBodyProps()}>
                {
                    page.map(row => {
                        prepareRow(row)
                        return (
                            <tr {...row.getRowProps()}>
                                {
                                    row.cells.map((cell) => {
                                        return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                                    })
                                }

                            </tr>
                        )
                    })
                }
            </tbody>
        </table>
        <div className="pagination">
            <button onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
                {'<<'}
            </button>{' '}
            <button onClick={() => previousPage()} disabled={!canPreviousPage}>
                {'<'}
            </button>{' '}
            <button onClick={() => nextPage()} disabled={!canNextPage}>
                {'>'}
            </button>{' '}
            <button onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
                {'>>'}
            </button>{' '}
        </div>
    </>
)
}

export function BillTable({ indata, total, setitems, settotals }) {
    console.log('indata', indata)
    console.log(total)
    const [tabledata, setData] = useState(indata)

    var columns = useMemo(() => BILLCOLUMNS, [])
    var data = useMemo(() => tabledata, [tabledata])


    useEffect(() => {
        console.log(tabledata)
        setData(indata)
    }, [indata])

    useEffect(() => {
        console.log('where', tabledata)
        console.log('table', data)
    }, [tabledata, data])


    const rmVal = (index, itemprice) => {
        let copy = indata

        let temp_total = {
            items: (total.items - copy[index].Quantity),
            price: (total.price - copy[index].itemtotal),
        }
        temp_total = { ...temp_total, grand: temp_total.price * (1 + GST) }
        copy.splice(index, 1)
        setitems(copy)
        settotals(temp_total)
        setData(copy)
        return copy
    }

    // const tablehooks = (hooks) => {
    //     hooks.visibleColumns.push((columns) => [
    //         ...columns,
    //         {
    //             id: 'actions',
    //             Header: 'Actions',
    //             Cell: (({ row }) => (
    //                 <button className={styles.remove} onClick={() => { removeData(row.values.id,indata) }}>Remove</button>
    //             ))

    //         }
    //     ]);
    // }


    const tableInstance = useTable({
        columns,
        data,
    },
    )

    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        rows,
        prepareRow } = tableInstance

    return (
        <table {...getTableProps()}>
            <thead>
                {headerGroups.map((headerGroup) => (
                    <tr {...headerGroup.getHeaderGroupProps}>
                        {
                            headerGroup.headers.map(column => (
                                <th {...column.getHeaderProps()}>{column.render('Header')}</th>
                            ))
                        }
                    </tr>
                ))}
            </thead>
            <tbody {...getTableBodyProps()}>
                {
                    rows.map(row => {
                        prepareRow(row)
                        return (
                            <tr {...row.getRowProps()}>
                                {
                                    row.cells.map((cell) => {
                                        return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                                    })
                                }
                                <td><AcButton onClick={() => {
                                    let x = rmVal(row.index, row.itemtotal)
                                    setData(x)
                                }}>Remove</AcButton></td>

                            </tr>
                        )
                    })
                }
            </tbody>

        </table>
    )
}


export function BillDashTable({ indata }) {
    var columns = useMemo(() => BILLTABLECOLS, [])
    var data = useMemo(() => indata, [indata])

    const tableInstance = useTable({
        columns,
        data,
    },
        useFilters,
        usePagination
    )

    const {
        page,
        getTableProps,
        getTableBodyProps,
        headerGroups,
        rows,
        prepareRow,
        canPreviousPage,
        canNextPage,
        pageOptions,
        pageCount,
        gotoPage,
        nextPage,
        previousPage,
        setPageSize,
        state: { pageIndex, pageSize }
    } = tableInstance

    useEffect(() => { setPageSize(3) }, [])
    return (
        <>
            {/* <table {...getTableProps} className={styles.mintable}>
            <thead>
                    {headerGroups.map((headerGroup) => (
                        <tr {...headerGroup.getHeaderGroupProps}>
                            {
                                headerGroup.headers.map(column => (
                                    <th {...column.getHeaderProps()}>
                                    {column.Header==='Sr' ? <h1>Customers</h1>: ""}
                                    {column.Header==="Name" ? <Link to="/newcust"> New Customer </Link> : ""}
                                    {column.Header==='Mobile' ? column.render('Filter') : ""}{console.log(column)}</th>
                                ))
                            }
                        </tr>
                    ))}
                </thead>
            </table> */}
            {/* <table {...getTableProps()}>
            
                <thead>
                    {headerGroups.map((headerGroup) => (
                        <tr {...headerGroup.getHeaderGroupProps}>
                            {
                                headerGroup.headers.map(column => (
                                    <th {...column.getHeaderProps()}><span>{column.canFilter ? column.render('Filter'):""}</span></th>
                                ))
                            }
                        </tr>
                    ))}
                </thead>
            </table> */}
            <table {...getTableProps()}>

                <thead>
                    {headerGroups.map((headerGroup) => (
                        <tr {...headerGroup.getHeaderGroupProps}>
                            {
                                headerGroup.headers.map(column => (
                                    <th {...column.getHeaderProps()}><span>{column.canFilter ? column.render('Filter') : ""}{column.render('Header')}</span></th>
                                ))
                            }
                        </tr>
                    ))}
                </thead>
                <tbody {...getTableBodyProps()}>
                    {
                        page.map(row => {
                            prepareRow(row)
                            return (
                                <tr {...row.getRowProps()}>
                                    {
                                        row.cells.map((cell) => {
                                            return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                                        })
                                    }

                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
            <div className="pagination">
                <Pagin onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
                    {'<<'}
                </Pagin>{' '}
                <Pagin onClick={() => previousPage()} disabled={!canPreviousPage}>
                    {'<'}
                </Pagin>{' '}
                <Pagin onClick={() => nextPage()} disabled={!canNextPage}>
                    {'>'}
                </Pagin>{' '}
                <Pagin onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
                    {'>>'}
                </Pagin>{' '}
            </div>
        </>
    )
}


export function NoReactTable({ indata, total, setitems, settotals }) {
    const [tabledata, setData] = useState(indata)
    useEffect(() => { setData(indata) }, [indata])
    const remRow = (e) => {
        let copy = tabledata

        let temp_total = {
            items: (total.items - copy[parseInt(e.target.name)].Quantity),
            price: (total.price - copy[parseInt(e.target.name)].itemtotal),
        }
        temp_total = { ...temp_total, grand: temp_total.price * (1 + GST) }
        copy = copy.filter((el, index) => index !== parseInt(e.target.name))
        settotals(temp_total)
        setData(copy)
        setitems(copy)
    }
    return (
        <table>
            <thead>
                <th>Sr</th>
                <th>Item</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
            </thead>
            <tbody>
                {tabledata.map((entry, index) => (
                    <tr>
                        <td>{entry.id}</td>
                        <td>{entry.Item}</td>
                        <td>{entry.Quantity}</td>
                        <td>{entry.Price}</td>
                        <td>{entry.itemtotal}</td>
                        <td><button name={index} onClick={remRow}>Remove</button></td>
                    </tr>
                ))}
            </tbody>
            <tfoot>
                <tr>
                    <td colSpan="4" style={{ textAlign: `right` }}>
                        Total
                    </td>
                    <td>
                        {total.price}
                    </td>
                </tr>
                <tr>
                    <td colSpan="4" style={{ textAlign: `right` }}>
                        GST
                    </td>

                    <td>{(total.price * (GST)).toFixed(2)}</td>
                </tr>
                <tr>
                    <td colSpan="4" style={{ textAlign: `right` }}>
                        Grand Total
                    </td>
                    <td>{(total.price * (1 + GST)).toFixed(2)}</td>
                </tr>
            </tfoot>
        </table>
    )
}