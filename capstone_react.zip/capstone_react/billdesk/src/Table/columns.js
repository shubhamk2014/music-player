import { Link } from 'react-router-dom'
import styled from 'styled-components'
import styles from './table.module.css'
import { ColumnFilter } from './columnfilter'
export const AcButton = styled.button`
    width:30px;
    height:30px;
    font-size:10px;
    `

export const CUSTCOLUMNS = [
    {
        Header : 'Sr',
        accessor: 'id'
    },
    {
        Header : 'Name',
        accessor : 'name'
    },
    {
        Header : 'Mobile',
        accessor : 'mobile',
        Cell: (({ row }) => (<>
            <Link to={"/custdeet/"+row.values.mobile}>{row.values.mobile}</Link>
            </>
        )),
        Filter : ColumnFilter,
    },
    
    {
        Header : 'Since',
        accessor : 'created'
    },
]

export const BILLCOLUMNS = [
    {
        Header: 'Sr',
        accessor: 'id'
    },
    {
        Header: 'Item',
        accessor: 'Item'
    },
    {
        Header: 'Quantity',
        accessor: 'Quantity'
    },
    {
        Header: 'Price',
        accessor: 'Price'
    },
    {
        Header: 'Total',
        accessor: 'itemtotal',
        Cell: (({row})=>(row.values.Quantity*row.values.Price))
    },
]

export const BILLTABLECOLS = [
    {
        Header: 'Sr',
        accessor: 'id',
        Filter : ColumnFilter,
    },
    {
        Header: 'Bill',
        accessor: 'billno',
        Cell: (({ row }) => (<>
            <Link to={"/billdetails/"+row.values.billno}>{row.values.billno}</Link>
            </>)),
        Filter : ColumnFilter,
    },
    {
        Header: 'Mobile',
        accessor: 'mobile',
        Cell: (({ row }) => (<>
            <Link to={"/custdeet/"+row.values.mobile}>{row.values.mobile}</Link>
            </>)),
        Filter : ColumnFilter,
    },
    {
        Header: 'Amount',
        accessor: 'amount',
        Filter : ColumnFilter,
    },
    {
        Header: 'Date',
        accessor: 'billdate',
        Filter : ColumnFilter,
    },
    {
        Header: 'Counter',
        accessor: 'counter',
        Filter : ColumnFilter,
    },
    {
        Header: 'Cashier',
        accessor: 'cashier',
        Filter : ColumnFilter,
    },
]